package com.yedam.service;

public interface MemberService {

}
