package com.yedam.vo;

public class MemberDTO {
 // VO 필드 정의
	
	
	
}
