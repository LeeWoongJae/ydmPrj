package com.yedam.main;

public class AppMain {
	public static void main(String[] args) {
		{
	        System.out.println( "Hello World!" );
	    }
	}
}
