package com.yedam.mapper;

public interface MemberMapper {
   // 계정 관련 매퍼
	
	
	
	
	
	
}
